#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include "lsupr.h"
#include "lsupr_ext.h"

//  stop : lit des caractères sur l'entrée standard jusqu'à détecter la fin de
//    l'entrée ou obtenir 'q', 'Q' ou '\n'. Renvoie zéro si '\n' est obtenu, une
//    valeur non nulle sinon.
int stop(void);

#define NMEMB 16

int main(void) {
  printf("--- Trials on lsupr module\n"
      "--- Type ctrl-d or enter 'q' or 'Q' to exit\n\n");
  srand(0);
  lsupr *s;
  while (1) {
    s = lsupr_empty();
    if (s == NULL) {
      goto error;
    }
    for (int k = 0; k < NMEMB; ++k) {
      supr x;
      supr_rand(&x);
      lsupr_insert_tail(s, &x);
    }
    printf("Avant quicksort: ");
    lsupr_fput(s, stdout);
    printf("\nAprès quicksort: ");
    lsupr_quicksort(s);
    lsupr_fput(s, stdout);
    lsupr_dispose(&s);
    printf("\n> ");
    if (stop()) {
      printf("\n");
      return EXIT_SUCCESS;
    }
  }
error:
  fprintf(stderr, "*** A fatal error occurs.\n");
  lsupr_dispose(&s);
  return EXIT_FAILURE;
}

int stop(void) {
  while (1) {
    int c = getchar();
    if (c == EOF || toupper(c) == 'Q') {
      return 1;
    }
    if (c == '\n') {
      return 0;
    }
  }
}
