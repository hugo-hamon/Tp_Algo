//  lsupr_ext : extension of the module lsupr. Extension du module lsupr.

#ifndef LSUPR_EXT__H
#define LSUPR_EXT__H

#include "lsupr.h"

//  lsupr_partition_pivot_tail : déplace respectivement en queue des listes
//    associées à slth, seq et sgth, les éléments de la liste associée à s qui
//    sont strictement inférieurs, égaux et strictement supérieurs au premier
//    élément de la liste associée à s. Si la liste associée à s est vide, les
//    quatre listes demeurent inchangées. À la terminaison, la liste associée à
//    s est vide, les éléments des listes associées à slth, seq et sgth sont
//    dans le même ordre que celui avec lequel ils figuraient originellement
//    dans s.
extern void lsupr_partition_pivot_tail(lsupr *s, lsupr *slth, lsupr *seq,
    lsupr *sgth);

//  lsupr_quicksort : trie de manière stable la liste associée à s selon la
//    méthode du tri rapide. Renvoie zéro en cas de succès, une valeur non nulle
//    en cas d'échec.
extern int lsupr_quicksort(lsupr *s);

#endif
