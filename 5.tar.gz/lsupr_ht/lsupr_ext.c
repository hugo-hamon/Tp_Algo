#include "lsupr_ext.h"

void lsupr_partition_pivot_tail(lsupr *s, lsupr *slth, lsupr *seq,
    lsupr *sgth) {
  supr pivot;
  if (lsupr_head_value(s, &pivot) != 0) {
    return;
  }
  supr curs;
  while (!lsupr_is_empty(s) && lsupr_head_value(s, &curs) != -1) {
    if (supr_compar(&pivot, &curs) == 0) {
      lsupr_move_head_tail(s, seq);
    } else if (supr_compar(&pivot, &curs) < 0) {
      lsupr_move_head_tail(s, slth);
    } else {
      lsupr_move_head_tail(s, sgth);
    }
  }
}

int lsupr_quicksort(lsupr *s) {
  if (lsupr_is_empty(s)) {
    return -1;
  }
  lsupr *slth = lsupr_empty();
  lsupr *seq = lsupr_empty();
  lsupr *sgth = lsupr_empty();
  if (slth == NULL || seq == NULL || sgth == NULL) {
    return -1;
  }
  lsupr_partition_pivot_tail(s, slth, seq, sgth);
  lsupr_quicksort(slth);
  lsupr_quicksort(sgth);
  lsupr_move_all_head(slth, s);
  lsupr_move_all_head(seq, s);
  lsupr_move_all_head(sgth, s);
  lsupr_dispose(&slth);
  lsupr_dispose(&seq);
  lsupr_dispose(&sgth);
  return 0;
}
