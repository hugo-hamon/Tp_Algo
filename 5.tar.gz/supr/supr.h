//  supr : Sequences of Upper case letters. Un module permettant de lire,
//    d'écrire, de générer de manière pseudo-aléatoire et de comparer des mots
//    (suites finies) de lettres majuscules de l'alphabet usuel (sans accent ni
//    cédille). Les mots sont mémorisés dans une structure nommée supr. La
//    manière dont sont rangées les lettres dans la structure n'est pas
//    spécifiée.
//
//    Le module est sensible aux éventuelles définitions préalables des
//    macroconstantes UPR_CARD, SUPR_LENGTH et SUPR_COMPAR_LENGTH. Seules les
//    lettres majuscules comprises entre la première, 'A', et la UPR_CARD-ième
//    lettre de l'alphabet usuel sont valides. Les mots ont tous pour longueur
//    SUPR_LENGTH. Seules les SUPR_COMPAR_LENGTH premières lettres des mots
//    sont prises en compte dans le test de comparaison.
//
//    Par défaut, c'est-à-dire si la macroconstante n'est pas définie au
//    préalable, UPR_CARD vaut 4, SUPR_LENGTH vaut 4 et SUPR_COMPAR_LENGTH vaut
//    SUPR_LENGTH.

#ifndef SUPR__H
#define SUPR__H

#define UPR_SET__FULL "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
#define UPR_CARD__MAX 26

_Static_assert(sizeof(UPR_SET__FULL) - 1 == UPR_CARD__MAX, "Internal error.");

#define UPR_CARD__DEFAULT 4

#ifndef UPR_CARD
#define UPR_CARD UPR_CARD__DEFAULT
#elif UPR_CARD <= 0 || UPR_CARD > UPR_CARD__MAX
#error Illegal value of UPR_CARD.
#endif

#define SUPR_LENGTH__DEFAULT 4

#ifndef SUPR_LENGTH
#define SUPR_LENGTH SUPR_LENGTH__DEFAULT
#elif SUPR_LENGTH <= 0
#error Illegal value of SUPR_LENGTH.
#endif

#ifndef SUPR_COMPAR_LENGTH
#define SUPR_COMPAR_LENGTH SUPR_LENGTH
#elif SUPR_COMPAR_LENGTH <= 0 || SUPR_COMPAR_LENGTH > SUPR_LENGTH
#error Illegal value of SUPR_COMPAR_LENGTH.
#endif

#include <stdio.h>

//  supr : nom d'une structure capable de mémoriser un mot de SUPR_LENGTH
//    lettres majuscules.
typedef struct {
  char reserved__usage[SUPR_LENGTH];
} supr;

//  supr_fget : lit sur le flot contrôlé par l'objet pointé par stream un mot
//    de SUPR_LENGTH lettres majuscules comprises entre la première et la
//    UPR_CARD-ième lettre de l'alphabet usuel et affecte la valeur associée à
//    l'objet pointé par ptr. La fonction renvoie EOF si une erreur survient
//    lors la lecture des éventuels caractères d'espacement initiaux. Elle
//    renvoie sinon 1 ou 0 selon que la lecture des SUPR_LENGTH lettres
//    majuscules a pu être menée à son terme ou non.
extern int supr_fget(supr *ptr, FILE *stream);

//  supr_fput : écrit sur le flot contrôlé par l'objet pointé par stream les
//    SUPR_LENGTH lettres majuscules du mot associé à l'objet pointé par ptr.
//    Renvoie EOF en cas d'échec et zéro en cas de succès.
extern int supr_fput(const supr *ptr, FILE *stream);

//  supr_rand : génère de manière pseudo-aléatoire un mot de SUPR_LENGTH lettres
//    majuscules comprises entre la première et la UPR_CARD-ième lettre de
//    l'alphabet usuel et affecte la valeur associée à l'objet pointé par ptr.
extern void supr_rand(supr *ptr);

//  supr_compar : compare le deux mots associés aux objets pointés par ptr1 et
//    ptr2 selon l'ordre lexicographique en ne considérant que leurs préfixes de
//    longueur SUPR_COMPAR_LENGTH. Renvoie une valeur strictement inférieure,
//    égale ou strictement supérieure à zéro selon que le premier mot est
//    strictement inférieur, égal ou strictement supérieur au second.
extern int supr_compar(const supr *ptr1, const supr *ptr2);

#endif
