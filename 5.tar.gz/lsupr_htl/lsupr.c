#include "lsupr.h"

typedef struct clsupr clsupr;

struct clsupr {
  supr value;
  clsupr *next;
};

struct lsupr {
  clsupr *head;
  clsupr *tail;
  size_t lenght;
};

lsupr *lsupr_empty(void) {
  lsupr *s = malloc(sizeof *s);
  if (s == NULL) {
    return NULL;
  }
  s->head = NULL;
  s->tail = NULL;
  s->lenght = 0;
  return s;
}

bool lsupr_is_empty(const lsupr *s) {
  return s->head == NULL || s->head == NULL;
}

size_t lsupr_length(const lsupr *s) {
  return s->lenght;
}

int lsupr_insert_head(lsupr *s, supr *ptr) {
  clsupr *p = malloc(sizeof *p);
  if (p == NULL) {
    return -1;
  }
  p->value = *ptr;
  p->next = s->head;
  if (lsupr_is_empty(s)) {
    s->tail = p;
  }
  s->head = p;
  s->lenght += 1;
  return 0;
}

int lsupr_insert_tail(lsupr *s, supr *ptr) {
  clsupr *p = malloc(sizeof *p);
  if (p == NULL) {
    return -1;
  }
  p->value = *ptr;
  p->next = NULL;
  if (!lsupr_is_empty(s)) {
    s->tail->next = p;
  }
  else {
    s->head = p;
  }
  s->tail = p;
  s->lenght += 1;
  return 0;
}

int lsupr_fput(const lsupr *s, FILE *stream) {
  clsupr *p = s->head;
  while (p != NULL) {
    if (supr_fput(&p->value, stream) == EOF || fputc(' ', stream) == EOF){
      return -1;
    }
    p = p->next;
  }
  if (fputc('\n', stream) == EOF){
    return -1;
  }
  return 0;
}

int lsupr_head_value(const lsupr *s, supr *ptr) {
  if (s->head == NULL) {
    return -1;
  }
  *ptr = s->head->value;
  return 0;
}

int lsupr_tail_value(const lsupr *s, supr *ptr) {
  if (s->tail == NULL) {
    return -1;
  }
  *ptr = s->tail->value;
  return 0;
}

int lsupr_move_head_head(lsupr *src, lsupr *dest) {
  if (src->head == NULL) {
    return -1;
  }
  clsupr *t = dest->head;
  clsupr *p = src->head->next;
  if (lsupr_is_empty(dest)) {
    dest-> tail = src -> tail;
  }
  dest->head = src->head;
  dest->head->next = t;
  src->head = p;
  if (src  -> head == NULL) {
    src ->tail = NULL;
  }
  src->lenght -= 1;
  dest->lenght += 1;
  return 0;
}

int lsupr_move_head_tail(lsupr *src, lsupr *dest) {
  if (lsupr_is_empty(src)) {
    return -1;
  }
  clsupr *t = dest->tail;
  clsupr *p = src->head->next;
  dest->tail = src->head; // tail de dest prend le premier element de src
  if (t != NULL){
    t->next = src->head; // l'ancienne queue prend en next la nouvelle queue
  } else {
    dest->head = src->head;
  }
  dest->tail->next = NULL; // next de la nouvelle queue prend la valeur NIL
  src->head = p; // head de src prend l'element suivant
  if (src->head == NULL ) {
    src->tail = NULL;
  }
  src->lenght -= 1;
  dest->lenght += 1;
  return 0;
}

int lsupr_move_all_head(lsupr *src, lsupr *dest) {
  if (src == dest) {
    return -1;
  }
  if (lsupr_is_empty(src)) {
    return 0;
  }
  if (lsupr_is_empty(dest)) {
    dest->tail = src->tail;
  }
  clsupr *p = dest->head; // ancienne tete de dest
  dest->head = src->head; // la tete de dest devient celle de src
  src->tail->next = p; // next de la queue de src devient p
  src->head = NULL;
  src->tail = NULL;
  dest->lenght = src->lenght + dest->lenght;
  src->lenght = 0;
  return 0;
}

int lsupr_move_all_tail(lsupr *src, lsupr *dest){
  if (src == dest) {
    return -1;
  }
  if (lsupr_is_empty(src)) {
    return 0;
  }
  if (lsupr_is_empty(dest)) {
    dest->head = src->head;
  } else {
    dest->tail->next = src->head;
  }
  dest->tail = src->tail;
  src->head = NULL;
  src->tail = NULL;
  dest->lenght = src->lenght + dest->lenght;
  src->lenght = 0;
  return 0;
}

void lsupr_dispose(lsupr **sptr) {
  clsupr *p = (*sptr)->head;
  while (p != NULL) {
    clsupr *t = p;
    p = p->next;
    free(t);
  }
  free(*sptr);
  *sptr = NULL;
}

