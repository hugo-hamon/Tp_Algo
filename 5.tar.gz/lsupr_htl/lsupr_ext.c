#include "lsupr_ext.h"

void lsupr_partition_pivot_tail(lsupr *s, lsupr *slth, lsupr *seq,
    lsupr *sgth) {
  supr pivot;
  if (lsupr_head_value(s, &pivot) != 0) {
    return;
  }
  supr curs;
  while (!lsupr_is_empty(s) && lsupr_head_value(s, &curs) != -1) {
    int c = supr_compar(&curs, &pivot);
    if (c == 0) {
      lsupr_move_head_tail(s, seq);
    } else if (c < 0) {
      lsupr_move_head_tail(s, slth);
    } else {
      lsupr_move_head_tail(s, sgth);
    }
  }
}

int lsupr_quicksort(lsupr *s) {
  lsupr *slth = lsupr_empty();
  lsupr *seq = lsupr_empty();
  lsupr *sgth = lsupr_empty();
  lsupr *sleft = lsupr_empty();
  lsupr *sright = lsupr_empty();
  while (lsupr_length(s) >= 2){
    lsupr_partition_pivot_tail(s, slth, seq, sgth);
    if (lsupr_length(slth) < lsupr_length(sgth)){
      lsupr_quicksort(slth);
      lsupr_move_all_tail(sgth, s);
      lsupr_move_all_tail(slth, sleft);
      lsupr_move_all_tail(seq, sleft);
    } else {
      lsupr_quicksort(sgth);
      lsupr_move_all_head(slth, s);
      lsupr_move_all_head(sgth, sright);
      lsupr_move_all_head(seq, sright);
    }
  }
  lsupr_move_all_head(sleft, s);
  lsupr_move_all_tail(sright, s);

  lsupr_dispose(&slth);
  lsupr_dispose(&seq);
  lsupr_dispose(&sgth);
  lsupr_dispose(&sleft);
  lsupr_dispose(&sright);
  return 0;
}
