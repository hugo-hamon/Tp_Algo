#include <stdlib.h>
#include <stdio.h>
#include "stack.h"
#include <limits.h>

//==============================================================================
#if 0

int main(void) {
  int r = EXIT_SUCCESS;
  long int n = 0;
  int c;
  char *t;
  stack *s = stack_empty();
  char w[UCHAR_MAX + 1];
  while ((c = getchar()) != EOF) {
    ++n;
    printf("%ld\t", n);
    while (c != EOF && c != '\n') {
      stack_push(s, w + c);
      c = getchar();
    }
    while (!stack_is_empty(s)) {
      t = (char *) stack_pop(s);
      putchar((int) (t - w));
    }
    putchar('\n');
  }
  if (!feof(stdin)) {
    r = EXIT_FAILURE;
  }
  stack_dispose(s);
  return r;
}

//==============================================================================
#else

int main(void) {
  int r = EXIT_SUCCESS;
  long int n = 0;
  int c;
  char *t;
  stack *s = stack_empty();
  stack *d = stack_empty();
  char w[UCHAR_MAX + 1];
  while ((c = getchar()) != EOF) {
    ++n;
    printf("%ld\t", n);
    while (c != EOF && c != '\n') {
      if (c == '#') {
        stack_pop(s);
      } else if (c == '@') {
        while (!stack_is_empty(s)) {
          stack_pop(s);
        }
      } else {
        stack_push(s, w + c);
      }
      c = getchar();
    }
    while (!stack_is_empty(s)) {
      stack_move(d, s);
    }
    while (!stack_is_empty(d)) {
      t = (char *) stack_pop(d);
      putchar((int) (t - w));
    }
    putchar('\n');
  }
  if (!feof(stdin)) {
    r = EXIT_FAILURE;
  }
  stack_dispose(&s);
  stack_dispose(&d);
  return r;
}

#endif
