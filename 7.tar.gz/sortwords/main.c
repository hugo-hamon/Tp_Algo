//  Affiche sur la sortie standard la liste des mots lus sur l'entrée standard
//    rangée dans l'ordre lexicographique.
//  Limitations :
//  - les mots sont obtenus par lecture sur l'entrée des suites consécutives
//    de longueur maximale mais majorée WORD_LENGTH_MAX de caractères qui ne
//    sont pas de la catégorie isspace ;
//  - toute suite de tels caractères de longueur strictement supérieure à
//    WORD_LENGTH_MAX se retrouve ainsi découpée en plusieurs mots.
//  Attention ! Le point suivant est à retravailler. Le laisser en l'état est
//    contraire aux exigences prônées :
//  - l'avertissement qui figure ligne 33 est une nuisance si le mot lu a
//    exactement la longueur WORD_LENGTH_MAX.

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "stack.h"

#define STR(s)  #s
#define XSTR(s) STR(s)

#define WORD_LENGTH_MAX 31

int main(void) {
  int r = EXIT_SUCCESS;
  stack *s = stack_empty();
  stack *trie = stack_empty();
  if (s == NULL || trie == NULL) {
    goto error_capacity;
  }
  char w[WORD_LENGTH_MAX + 1];
  while (scanf("%" XSTR(WORD_LENGTH_MAX) "s", w) == 1) {
    if (strlen(w) == WORD_LENGTH_MAX) {
      fprintf(stderr, "*** Warning: Word '%s...' possibly sliced.\n", w);
    }
    char *t = malloc(strlen(w) + 1);
    if (t == NULL) {
      goto error_capacity;
    }
    strcpy(t, w);
    const char *top_trie = stack_top(trie);
    if (top_trie == NULL) {
      if (stack_push(trie, t) == NULL) {
        free(t);
        goto error_capacity;
      }
    } else if (strcmp(t, top_trie) < 0) { // Cas nouvel élément inférieure à
                                          // l'élément en haut de trie
      const char *top_s = stack_top(s);
      while (top_s != NULL && strcmp(t, top_s) < 0) {
        if (stack_move(trie, s) == NULL) {
          free(t);
          goto error_capacity;
        }
        top_s = stack_top(s);
      }
      if (stack_push(trie, t) == NULL) {
        free(t);
        goto error_capacity;
      }
    } else { // Cas nouvel élément supérieure à l'élément en haut de trie
      while (top_trie != NULL && strcmp(t, top_trie) > 0) {
        if (stack_move(s, trie) == NULL) {
          free(t);
          goto error_capacity;
        }
        top_trie = stack_top(trie);
      }
      if (stack_push(trie, t) == NULL) {
        free(t);
        goto error_capacity;
      }
    }
  }
  while (!stack_is_empty(s)) {
    if (stack_move(trie, s) == NULL) {
      goto error_capacity;
    }
  }
  if (!feof(stdin)) {
    goto error_read;
  }
  while (!stack_is_empty(trie)) {
    char *t = (char *) stack_pop(trie);
    printf("%s\n", t);
    free(t);
  }
  goto dispose;
error_capacity:
  fprintf(stderr, "*** Error: Not enough memory.\n");
  goto error;
error_read:
  fprintf(stderr, "*** Error: A read error occurs.\n");
  goto error;
error:
  r = EXIT_FAILURE;
  goto dispose;
dispose:
  stack_dispose(&s);
  stack_dispose(&trie);
  return r;
}
