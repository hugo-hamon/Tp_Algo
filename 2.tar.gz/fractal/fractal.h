#ifndef FRACTAL__H
#define FRACTAL__H

//  fitted_squares : produit la figure fractale d'ordre n des carrés emboités à
//    l'intérieur d'un carré dont la longueur des côtés exprimée en pixels est
//    size. Si une demande d'abandon est détectée, renvoie une valeur non
//    nulle ; renvoie zéro sinon.
extern int fitted_squares(unsigned int size, int n);

//  sierpinski carpet : produit la figure fractale d'ordre n des neuf carrés
//    donc la longueur des cotés explimée en pixels est size / 3, et en
//    supprimant la pièce centrale.
//    Si une demande d'abandon est détectée, renvoie une valeur non
//    nulle ; renvoie zéro sinon.
extern int carpet(unsigned int size, int n);

//  koch : produit la figure fractale d'ordre n d'une courbe coupé en trois
//    segment avec un triangle equilateral ayant pour base le segment median de
//    la premiere etape avec ensuite le deuxiéme segment suprimé.
//    Si une demande d'abandon est détectée, renvoie une valeur non
//    nulle ; renvoie zéro sinon.
extern int koch(unsigned int size, int n);

// julia: produit la figure fractalle d'ordre n de julia en fonction du
//    parametre un et de c. Si une demande d'abandon est détectée, renvoie une
//    valeur non nulle ; renvoie zéro sinon.
extern int julia(unsigned int size, int n);

// dragon: produit la figure fractalle d'ordre n de la courbe du dragon a
//    partir d'un segment de base ; puis en suivant la courbe, remplacer chaque
// segment par deux segments à angle droit en effectuant une rotation de 45°
// alternativement à droite puis à gauche. Si une demande
// d'abandon est détectée, renvoie une
//    valeur non nulle ; renvoie zéro sinon.
extern int dragon(unsigned int size, int n);

// vicsek: produit la figure fractalle d'ordre n de la fractale de vicsek qui
//     résulte d'une construction similaire à celle du tapis de Sierpinski. Le
// carré unité est décomposé en neuf sous-carreaux sur la grille régulière 3 par
// 3. Les carreaux dans les coins sont enlevés, les cinq autres restent. Ce
// procédé est récursivement répété pour les carreaux gardés. Si une demande
// d'abandon est détectée, renvoie une
//    valeur non nulle ; renvoie zéro sinon.
extern int vicsek(unsigned int size, int n);

// vicsek_variant: produit la figure fractalle d'ordre n de la fractale de
// vicsek qui résulte d'une construction similaire à celle du tapis de
// Sierpinski. Le carré unité est décomposé en neuf sous-carreaux sur la grille
// régulière 3 par 3. Les carreaux des cotés sont enlevés, les quatre autres
// restent. Ce procédé est récursivement répété pour les carreaux gardés. Si une
// demande d'abandon est détectée, renvoie une valeur non nulle ; renvoie zéro
// sinon.
extern int vicsek_variant(unsigned int size, int n);

#endif
