#include <stdio.h>
#include <string.h>
#include <complex.h>
#include <stdbool.h>
#include <math.h>
#include "point.h"
#include "sg.h"
#include "fractal.h"

#define QUIT  'q'

#define TITLE_ORDER " / order = "

//  ndigits : renvoie le nombre de chiffres de n dans son écriture en base base,
//    en supposant n >= 0 et base >= 2.
static size_t ndigits(int n, int base) {
  if (n < base) {
    return 1;
  }
  return ndigits(n / base, base);
}

//  set_title : efface la fenêtre, affiche le titre title avec affichage de
//    l'ordre n, en supposant n >= 0.
static void make_title(const char *title, int n) {
  sg_clear();
  char s[strlen(title) + strlen(TITLE_ORDER) + ndigits(n, 10) + 1];
  sprintf(s, "%s%s%d", title, TITLE_ORDER, n);
  sg_set_title(s);
}

//  graduate_color : fixe la couleur de premier plan entre le vert et le marron
//    proportionnellement à k, en supposant 0 <= k <= n et n >= 1.
static void graduate_color(int k, int n) {
  sg_set_fgcolor(
      COLOR((int) (RGBMAX * (double) k / n), RGBMAX / 2, RGBMAX / 4));
}

//--- Carrés emboités ----------------------------------------------------------

#define SHIFT 5.0

//  r_fitted_4 : produit l'emboité d'ordre n du quadrilatère de sommets pa, pb,
//    pc et pd avec rotation droite de proportion 1 / (SHIFT + 1).
static void r_fitted_4(int n, point pa, point pb, point pc, point pd) {
  if (n < 0) {
    return;
  }
  draw_line(pa, pb);
  draw_line(pb, pc);
  draw_line(pc, pd);
  draw_line(pd, pa);
  if (n == 0) {
    return;
  }
  r_fitted_4(n - 1,
      barycenter(pa, SHIFT, pb, 1.0),
      barycenter(pb, SHIFT, pc, 1.0),
      barycenter(pc, SHIFT, pd, 1.0),
      barycenter(pd, SHIFT, pa, 1.0));
}

int fitted_squares(unsigned int size, int n) {
  unsigned int d = size / 10;
  for (int k = 0; k <= n; ++k) {
    make_title("Fitted squares", k);
    graduate_color(k, n);
    r_fitted_4(k,
        (point) { d, d },
        (point) { size - d, d },
        (point) { size - d, size - d },
        (point) { d, size - d });
    if (sg_get_key() == QUIT) {
      return -1;
    }
  }
  return 0;
}

//--- Tapis de Sierpinski ------------------------------------------------------

//  r_carpet: produit l'emboité d'ordre n du carret de sommet p et de longueur
//    width.

static void r_carpet(int n, point p, unsigned int width) {
  if (n < 0) {
    return;
  }
  sg_set_fgcolor(BLACK);
  fill_rectangle(p, width, width);
  sg_set_fgcolor(WHITE);
  width /= 3;
  fill_rectangle((point) {p.x + width, p.y + width}, width, width);
  if (n == 0) {
    return;
  }
  r_carpet(n - 1, p, width); // BL
  r_carpet(n - 1, (point) {p.x + width, p.y}, width); // BM
  r_carpet(n - 1, (point) {p.x + 2 * width, p.y}, width); // BR
  r_carpet(n - 1, (point) {p.x, p.y + width}, width); // ML
  r_carpet(n - 1, (point) {p.x + 2 * width, p.y + width}, width); // MR
  r_carpet(n - 1, (point) {p.x, p.y + 2 * width}, width); // TL
  r_carpet(n - 1, (point) {p.x + width, p.y + 2 * width}, width); // TM
  r_carpet(n - 1, (point) {p.x + 2 * width, p.y + 2 * width},
      width); // TR
}

int carpet(unsigned int size, int n) {
  for (int k = 0; k <= n; ++k) {
    make_title("Sierpinski carpet", k);
    r_carpet(k, (point) {0, 0}, size);
    if (sg_get_key() == QUIT) {
      return -1;
    }
  }
  return 0;
}

//--- Koch ---------------------------------------------------------------------

static void r_koch(int n, point p1, point p2) {
  if (n < 0) {
    return;
  }
  sg_set_fgcolor(WHITE);
  if (n == 0) {
    draw_line(p1, p2);
    return;
  }
  point bary1 = barycenter(p1, 2, p2, 1);
  point bary2 = barycenter(p1, 1, p2, 2);
  point equi = equilateral_triangle(bary2, bary1);
  r_koch(n - 1, p1, bary1);
  r_koch(n - 1, bary1, equi);
  r_koch(n - 1, equi, bary2);
  r_koch(n - 1, bary2, p2);
}

int koch(unsigned int size, int n) {
  for (int k = 0; k <= n; ++k) {
    make_title("Koch curve", k);
    r_koch(k, (point) {0, size / 2}, (point) {size, size / 2});
    if (sg_get_key() == QUIT) {
      return -1;
    }
  }
  return 0;
}

//--- Fractal de Julia ---------------------------------------------------------

// convert: convertie un point de l'ecran en nombre complexe suivant la formule
// z = a + ib avec bi1 <= a <= bs1 && bi2 <= b <= bs2 et renvoie un nombre
// complex
complex double convert(double a, double b, double bi1, double bs1, double bi2,
    double bs2, unsigned int size) {
  complex double z = a / size * (fabs(bi1) + fabs(bs1)) - bs1
      + (b / size * (fabs(bi2) + fabs(bs2)) - bs2) * I;
  return z;
}

// mod: retourne le module d'un nombre complex z
double mod(complex double z) {
  return sqrt(pow(creal(z), 2) + pow(cimag(z), 2));
}

// is_julia: prend en parametre un nombre complex u, un nombre complex c et un
// entier n. renvoie si un nombre complexe est de julia ou non définie t'elle
// que un = (un-1)² + c. si mod(k) < 2 pour 0 <= k <= n et k = un alors u est un
// nombre de julia.
bool is_julia(complex double u, complex double c, int n) {
  complex double k = u;
  while (n > 0 && mod(k) < 2) {
    k = cpow(k, 2) + c;
    --n;
  }
  if (n == 0) {
    return true;
  }
  return false;
}

static void r_julia(double a1, double b1, double a2, double b2,
    unsigned int size, unsigned int i, unsigned j,
    complex double c, int n) {
  if (i > size || j > size) {
    return;
  }
  if (is_julia(convert(i, j, a1, b1, a2, b2, size), c, n)) {
    sg_set_fgcolor(BLACK);
    draw_point((point) {i, j});
  } else {
    sg_set_fgcolor(WHITE);
    draw_point((point) {i, j});
  }
  if (i == size && j == size) {
    return;
  }
  r_julia(a1, b1, a2, b2, size, i % size + 1, j + (i == size), c, n);
}

int julia(unsigned int size, int n) {
  complex double c = -0.85 + 0.2 * I;
  make_title("Julia", n);
  r_julia(-1.5, 1.5, -1.5, 1.5, size, 0, 0, c, 100);
  if (sg_get_key() == QUIT) {
    return -1;
  }
  return 0;
}

//--- Fractal du dragon --------------------------------------------------------
static void r_dragon(int n, point p1, point p2) {
  if (n < 0) {
    return;
  }
  if (n == 0) {
    draw_line(p1, p2);
    return;
  }
  point rp = right_angle_triangle(p1, p2);
  r_dragon(n - 1, p1, rp);
  r_dragon(n - 1, p2, rp);
}

int dragon(unsigned int size, int n) {
  for (int k = 0; k <= n; ++k) {
    make_title("Dragon curve", k);
    r_dragon(k, (point) {size/4, size / 2}, (point) {size-100, size / 2});
    if (sg_get_key() == QUIT) {
      return -1;
    }
  }
  return 0;
}
//--- Vicsek snowflake -------------------------------------------------------------
static void r_vicsek(int n, point p, unsigned int len) {
  if (n < 0) {
    return;
  }
  sg_set_fgcolor(WHITE);
  fill_rectangle(p, len, len);
  sg_set_fgcolor(BLACK);
  len /= 3;
  fill_rectangle((point) {p.x + len, p.y}, len, len * 3);
  fill_rectangle((point) {p.x, p.y + len}, len * 3, len);
  if (n == 0) {
    return;
  }
  r_vicsek(n - 1, (point) {p.x + len, p.y},len); // BM
  r_vicsek(n - 1, (point) {p.x, p.y + len},len); // ML
  r_vicsek(n - 1, (point) {p.x + len, p.y + len},len); // M
  r_vicsek(n - 1, (point) {p.x + 2 * len, p.y + len},len); // MR
  r_vicsek(n - 1, (point) {p.x + len, p.y + 2 * len},len); // TM
}

int vicsek(unsigned int size, int n) {
  for (int k = 0; k <= n; ++k) {
    make_title("vicksek cross", k);
    r_vicsek(k, (point) {0, 0}, size);
    if (sg_get_key() == QUIT) {
      return -1;
    }
  }
  return 0;
}

//--- Vicsek snowflake variant--------------------------------------------------
static void r_vicsek_variant(int n, point p, unsigned int len) {
  if (n < 0) {
    return;
  }
  sg_set_fgcolor(WHITE);
  fill_rectangle(p, len, len);
  sg_set_fgcolor(BLACK);
  len /= 3;
  fill_rectangle((point) {p.x, p.y}, len, len);
  fill_rectangle((point) {p.x + 2 * len, p.y}, len, len);
  fill_rectangle((point) {p.x + len, p.y + len}, len, len);
  fill_rectangle((point) {p.x, p.y + 2 * len}, len, len);
  fill_rectangle((point) {p.x + 2 * len, p.y + 2 * len}, len, len);
  if (n == 0) {
    return;
  }
  r_vicsek_variant(n - 1, (point) {p.x, p.y},len); // BL
  r_vicsek_variant(n - 1, (point) {p.x + 2 * len, p.y},len); // BR
  r_vicsek_variant(n - 1, (point) {p.x + len, p.y + len},len); // M
  r_vicsek_variant(n - 1, (point) {p.x, p.y + 2 * len},len); // TL
  r_vicsek_variant(n - 1, (point) {p.x + 2 * len, p.y + 2 * len},len); // TR
}

int vicsek_variant(unsigned int size, int n) {
  for (int k = 0; k <= n; ++k) {
    make_title("vicksek snowflake variant", k);
    r_vicsek_variant(k, (point) {0, 0}, size);
    if (sg_get_key() == QUIT) {
      return -1;
    }
  }
  return 0;
}
