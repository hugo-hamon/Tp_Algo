#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <complex.h>
#include "fractal.h"
#include "sg.h"

#define SIZE_DEFAULT 650

int main(void) {
  sg_open(SIZE_DEFAULT, SIZE_DEFAULT, BLACK, WHITE, "Recursive graphs");
  if (fitted_squares(SIZE_DEFAULT, 10) == 0
      && koch(SIZE_DEFAULT, 7) == 0
      && carpet(SIZE_DEFAULT, 5) == 0
      && julia(SIZE_DEFAULT, 5) == 0
      && dragon(SIZE_DEFAULT, 17) == 0
      && vicsek(SIZE_DEFAULT, 4) == 0
      && vicsek_variant(SIZE_DEFAULT, 4) == 0
      ) {
  }
  sg_close();
  return EXIT_SUCCESS;
}
