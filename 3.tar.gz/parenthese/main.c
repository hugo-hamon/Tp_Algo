#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

// is_parenthesized_aux : comme is_parenthesized sauf que la fonction renvoie
// n == 0 par défaut
bool is_parenthesized_aux(const char *s, int n);
// is_parenthesized : prend une chaine de caractére en parametre et renvoie vrai
// si celle-ci est parenthésée faux sinon
bool is_parenthesized(const char *s);

#define MAX_NUMBER_OF_STRING 6

int main(void) {
  const char *s[MAX_NUMBER_OF_STRING] = {
    "(x²+1)", "\0", "(x²+1", "x²+1)", ")x²+1(", ""
  };
  for (int i = 0; i < MAX_NUMBER_OF_STRING; ++i) {
    bool res = is_parenthesized(s[i]);
    if (res) {
      printf("%s est bien parenthésée\n", s[i]);
    } else {
      printf("%s est mal parenthésée\n", s[i]);
    }
  }
  return EXIT_SUCCESS;
}

bool is_parenthesized(const char *s) {
  return is_parenthesized_aux(s, 0);
}

bool is_parenthesized_aux(const char *s, int n) {
  if (n < 0) {
    return false;
  }
  if (*s == '\0') {
    return n == 0;
  }
  if (*s == '(') {
    n += 1;
  }
  if (*s == ')') {
    n -= 1;
  }
  return is_parenthesized_aux(s + 1, n);
}
