#include "str_rec.h"

char *str_chr(const char *s, int c) {
  if (*s == c) {
    return (char *) s;
  }
  if (*s == '\0') {
    return NULL;
  }
  return str_chr(s + 1, c);
}

char *str_pbrk(const char *s1, const char *s2) {
  if (*s1 == '\0') {
    return NULL;
  }
  if (str_chr(s2, *s1) != NULL) {
    return (char *) s1;
  }
  return str_pbrk(s1 + 1, s2);
}

// str_rchr_aux : comme str_rchr, sauf que la fonction renvoie bydefault si c
// n'apparait pas dans s.

char *str_rchr_aux(const char *s, int c, const char *bydefault) {
  if (*s == '\0') {
    return (c == '\0') ? (char *) s : (char *) bydefault;
  }
  if (*s == c) {
    bydefault = s;
  }
  return str_rchr_aux(s + 1, c, bydefault);
}

char *str_rchr(const char *s, int c) {
  return str_rchr_aux(s, c, NULL);
}

// str_rspn_aux: comme str_spn, sauf que la fonction renvoie n si aucun
// charactere de s2 n'apparait dans s1.

size_t str_spn_aux(const char *s1, const char *s2, size_t n) {
  if (*s1 == '\0' || str_chr(s2, *s1) == NULL) {
    return n;
  }
  return str_spn_aux(s1 + 1, s2, n + 1);
}

size_t str_spn(const char *s1, const char *s2) {
  return str_spn_aux(s1, s2, 0);
}
