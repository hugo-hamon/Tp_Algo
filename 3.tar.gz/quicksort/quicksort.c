#include "quicksort.h"
#include <stdio.h>

void mem_swap(void *p1, void *p2, size_t size) {
  if (size == 0) {
    return;
  }
  int c = *((char *) p1);
  *((char *) p1) = *((char *) p2);
  *((char *) p2) = (char) c;
  mem_swap((char *) p1 + 1, (char *) p2 + 1, size - 1);
}

void *partition_pivot(void *base, size_t nmemb, size_t size,
    int (*compar)(const void *, const void *)) {
  if (nmemb == 0) {
    return NULL;
  }
  char *p = base;
  char *q = base;
  char *k = (char *) base + (nmemb - 1) * size;
  while (q < k) {
    if (compar(q, k) < 0) {
      mem_swap(p, q, size);
      p += size;
    }
    q += size;
  }
  mem_swap(p, k, size);
  return (void *) p;
}

// quicksort_aux : meme que quicksort sauf que celle ci est partiellement
// derecursifier
void quicksort_aux(void *base, size_t nmemb, size_t size,
    int (*compar)(const void *, const void *)) {
  //char *j = base;
  //char *k = (char *) base + (nmemb - 1) * size;
  while (nmemb > 1) {
    char *p = partition_pivot(base, nmemb, size, compar);
    if (p - (char *) base < (char *) base + (nmemb - 1) * size - p) {
      quicksort_aux(base, (size_t) (p - (char *) base) / size, size, compar);
      base = p + size;
      nmemb = (size_t) ((char *) base + (nmemb - 1) * size - p) / size;
    } else {
      quicksort_aux(p + size,
          (size_t) ((char *) base + (nmemb - 1) * size - p) / size,
          size, compar);
      nmemb = (size_t) (p - (char *) base) / size;
    }
  }
}

void quicksort(void *base, size_t nmemb, size_t size,
    int (*compar)(const void *, const void *)) {
  if (nmemb <= 1) {
    return;
  }
  quicksort_aux(base, nmemb, size, compar);
}
