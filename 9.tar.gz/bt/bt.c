//  Implantation pour la spécification ABIN du TDA ABin.

#include "bt.h"

//=== Type cbt =================================================================

//--- Définition cbt -----------------------------------------------------------

typedef struct cbt cbt;

struct cbt {
  cbt *next[2];
};

//--- Raccourcis cbt -----------------------------------------------------------

#define EMPTY()     NULL
#define IS_EMPTY(p) ((p) == NULL)
#define LEFT(p)     ((p)->next[0])
#define RIGHT(p)    ((p)->next[1])

//--- Divers -------------------------------------------------------------------

static size_t add__size_t(size_t x1, size_t x2) {
  return x1 + x2;
}

static size_t max__size_t(size_t x1, size_t x2) {
  return x1 > x2 ? x1 : x2;
}

static size_t min__size_t(size_t x1, size_t x2) {
  return x1 < x2 ? x1 : x2;
}

//--- Fonctions cbt ------------------------------------------------------------

//  cbt__dispose : libère les ressources allouées à l'arbre binaire pointé par
//    p.
static void cbt__dispose(cbt *p) {
  if (!IS_EMPTY(p)) {
    cbt__dispose(LEFT(p));
    cbt__dispose(RIGHT(p));
    free(p);
  }
}

//  cbt__root : renvoie l'arbre binaire dont les deux sous-arbres gauche et
//    droit sont left et right. En cas d'erreur d'allocation, libère les
//    ressources allouées à left et right et renvoie l'arbre vide.
static cbt *cbt__root(cbt *left, cbt *right) {
  cbt *p = malloc(sizeof *p);
  if (p == NULL) {
    cbt__dispose(left);
    cbt__dispose(right);
    return EMPTY();
  }
  LEFT(p) = left;
  RIGHT(p) = right;
  return p;
}

//  cbt__comb_left : renvoie un peigne gauche de taille n. Si n n'est pas nul et
//    qu'une erreur d'allocation survient, renvoie un peigne gauche de taille
//    strictement inférieure à n.
static cbt *cbt__comb_left(size_t n) {
  return n == 0
         ? EMPTY()
         : cbt__root(cbt__comb_left(n - 1), EMPTY());
}

//  cbt__comb_right : renvoie un peigne droit de taille n. Si n n'est pas nul et
//    qu'une erreur d'allocation survient, renvoie un peigne droit de taille
//    strictement inférieure à n.
static cbt *cbt__comb_right(size_t n) {
  return (n == 0) ? EMPTY() : cbt__root(EMPTY(), cbt__comb_right(n - 1));
}

//  cbt__random : renvoie un arbre binaire aléatoire de taille n. Si n n'est pas
// nul et qu'une erreur d'allocation survient, renvoie un arbre binaire
// aléatoire de taille strictement inférieure à n.
static cbt *cbt__random(size_t n) {
  if (n == 0) {
    return EMPTY();
  }
  size_t k = (size_t) rand() %  n;
  return cbt__root(cbt__random(k), cbt__random(n - 1 - k));
}

//  DEFUN_CBT__MEASURE : définit la fonction récursive de nom cbt__ ## <fun> et
//    de paramètre un arbre binaire p, qui renvoie zéro si p est l'arbre vide et
//    1 + <oper>(r0, r1) sinon, où r0 et r1 sont les valeurs renvoyées par les
//    appels récursifs de la fonction sur les sous-arbres gauche et droit de p.
#define DEFUN_CBT__MEASURE(fun, oper)                                          \
  static size_t cbt__ ## fun(const cbt * p) {                                  \
    return IS_EMPTY(p)                                                         \
           ? 0                                                                      \
           : 1 + oper(cbt__ ## fun(LEFT(p)), cbt__ ## fun(RIGHT(p)));               \
  }

//  cbt__size, cbt__height, cbt__distance : définition.

DEFUN_CBT__MEASURE(size, add__size_t)
DEFUN_CBT__MEASURE(height, max__size_t)
DEFUN_CBT__MEASURE(distance, min__size_t)

static bool cbt__is_skinny(const cbt *p) {
  if (IS_EMPTY(p)) {
    return true;
  }
  if (!IS_EMPTY(LEFT(p)) && !IS_EMPTY(RIGHT(p))) {
    return false;
  }
  if (!IS_EMPTY(LEFT(p))) {
    return cbt__is_skinny(LEFT(p));
  } else {
    return cbt__is_skinny(RIGHT(p));
  }
}

static bool cbt__is_comb_left(const cbt *p) {
  if (IS_EMPTY(p)) {
    return true;
  }
  if (!IS_EMPTY(RIGHT(p))) {
    return false;
  }
  return cbt__is_comb_left(LEFT(p));
}

static bool cbt__is_comb_right(const cbt *p) {
  if (IS_EMPTY(p)) {
    return true;
  }
  if (!IS_EMPTY(LEFT(p))) {
    return false;
  }
  return cbt__is_comb_right(RIGHT(p));
}

static bool cbt__is_similar(const cbt *p1, const cbt *p2) {
  if (IS_EMPTY(p1) || IS_EMPTY(p2)) {
    return IS_EMPTY(p1) && IS_EMPTY(p2);
  }
  return cbt__is_similar(LEFT(p1), LEFT(p2)) && cbt__is_similar(RIGHT(p1),
      RIGHT(p2));
}

//  cbt__repr_formal : affiche la représentation formelle de l'arbre binaire p.

#define REPR__SYM_FORMAL_LPAR "("
#define REPR__SYM_FORMAL_RPAR ")"
#define REPR__SYM_FORMAL_SEP  " "

static void cbt__repr_formal(const cbt *p) {
  printf(REPR__SYM_FORMAL_LPAR);
  if (!IS_EMPTY(p)) {
    cbt__repr_formal(LEFT(p));
    printf(REPR__SYM_FORMAL_SEP);
    cbt__repr_formal(RIGHT(p));
  }
  printf(REPR__SYM_FORMAL_RPAR);
}

#define REPR__SYM_LUKAS_NPAR "a"
#define REPR__SYM_LUKAS_EPAR "b"

static void cbt__repr_lukas(const cbt *p){
  printf(REPR__SYM_LUKAS_NPAR);
  if (!IS_EMPTY(p)){
    if (!IS_EMPTY(LEFT(p))){
      cbt__repr_lukas(LEFT(p));
    } else {
      printf(REPR__SYM_LUKAS_EPAR);
    }
    if (!IS_EMPTY(RIGHT(p))){
      cbt__repr_lukas(RIGHT(p));
    } else {
      printf(REPR__SYM_LUKAS_EPAR);
    }
  }
}

static void cbt__repr_subtrees(const cbt *p){
  if (!IS_EMPTY(p)){
    printf("%d", IS_EMPTY(LEFT(p)) ? 0 : 1);
    printf("%d", IS_EMPTY(RIGHT(p)) ? 0 : 1);
    cbt__repr_subtrees(LEFT(p));
    cbt__repr_subtrees(RIGHT(p));
  }
}

#define REPR__TAB 4

//  cbt__repr_graphic : affiche la représentation graphique par rotation
//    antihoraire d'un quart de tour du sous-arbre binaire p avec une
//    indentation par niveau de REPR__TAB caractères. Le niveau du sous-arbre
//    est supposé être la valeur de level.

#define REPR__SYM_GRAPHIC_NPAR "O"
#define REPR__SYM_GRAPHIC_EPAR "|"

static void cbt__repr_graphic(const cbt *p, size_t level){
  if (!IS_EMPTY(p)){
    if (!IS_EMPTY(RIGHT(p))){
      printf("%*c", (int)level*REPR__TAB + 1, ' ');
    }
  }
}

//=== Type bt ==================================================================

//--- Définition bt ------------------------------------------------------------

struct bt {
  cbt *root;
};

//--- Fonctions bt -------------------------------------------------------------

bt *bt_comb_left(size_t n) {
  bt *t = malloc(sizeof *t);
  if (t == NULL) {
    return NULL;
  }
  cbt *p = cbt__comb_left(n);
  if (cbt__size(p) != n) {
    free(t);
    cbt__dispose(p);
    return NULL;
  }
  t->root = p;
  return t;
}

bt *bt_comb_right(size_t n) {
  bt *t = malloc(sizeof *t);
  if (t == NULL) {
    return NULL;
  }
  cbt *p = cbt__comb_right(n);
  if (cbt__size(p) != n) {
    free(t);
    cbt__dispose(p);
    return NULL;
  }
  t->root = p;
  return t;
}

bt *bt_random(size_t n) {
  bt *t = malloc(sizeof *t);
  if (t == NULL) {
    return NULL;
  }
  cbt *p = cbt__random(n);
  if (cbt__size(p) != n) {
    free(t);
    cbt__dispose(p);
    return NULL;
  }
  t->root = p;
  return t;
}

void bt_dispose(bt **tptr) {
  if (*tptr == NULL) {
    return;
  }
  cbt__dispose((*tptr)->root);
  free(*tptr);
  *tptr = NULL;
}

size_t bt_size(bt *t) {
  return cbt__size(t->root);
}

size_t bt_height(bt *t) {
  return cbt__height(t->root);
}

size_t bt_distance(bt *t) {
  return cbt__distance(t->root);
}

bool bt_is_skinny(bt *t) {
  return cbt__is_skinny(t->root);
}

bool bt_is_comb_left(bt *t) {
  return cbt__is_comb_left(t->root);
}

bool bt_is_comb_right(bt *t) {
  return cbt__is_comb_right(t->root);
}

bool bt_is_similar(bt *t1, bt *t2){
  return cbt__is_similar(t1->root, t2->root);
}

void bt_repr_formal(bt *t) {
  cbt__repr_formal(t->root);
}

void bt_repr_lukas(bt *t){
  cbt__repr_lukas(t->root);
}

void bt_repr_subtrees(bt *t){
  cbt__repr_subtrees(t->root);
}

void bt_repr_graphic(bt *t){
  cbt__repr_graphic(t->root, 4);
}

//  ICI, PROCHAINEMENT, LA DÉFINITION DE :
//    bt_repr_graphic
