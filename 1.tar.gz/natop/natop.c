#include "natop.h"

nat sum(nat x, nat y) {
  if (is_undef(x) || is_undef(y)) {
    return undef();
  }
  if (is_infty(x)) {
    return infty();
  }
  if (is_zero(x) || is_infty(y)) {
    return y;
  }
  return sum(pred(x), succ(y));
}

nat dist(nat x, nat y) {
  if (is_undef(x) || is_undef(y)) {
    return undef();
  }
  if (is_infty(x) || is_infty(y)) {
    return infty();
  }
  if (is_zero(x)) {
    return y;
  }
  if (is_zero(y)) {
    return x;
  }
  return dist(pred(x), pred(y));
}

nat min(nat x, nat y) {
  if (is_undef(x) || is_undef(y)) {
    return undef();
  }
  if (is_infty(x)) {
    return y;
  }
  if (is_infty(y)) {
    return x;
  }
  if (is_zero(x)) {
    return x;
  }
  if (is_zero(y)) {
    return y;
  }
  return succ(min(pred(x), pred(y)));
}

nat max(nat x, nat y) {
  if (is_undef(x) || is_undef(y)) {
    return undef();
  }
  if (is_infty(x)) {
    return y;
  }
  if (is_infty(y)) {
    return x;
  }
  if (is_zero(x)) {
    return y;
  }
  if (is_zero(y)) {
    return x;
  }
  return succ(max(pred(x), pred(y)));
}

bool is_eq(nat x, nat y) {
  if (is_undef(x) || is_undef(y) || is_infty(x) || is_infty(y)) {
    return false;
  }
  if (is_zero(x) && is_zero(y)) {
    return true;
  }
  if (is_zero(x) || is_zero(y)) {
    return false;
  } else {
    return is_eq(pred(x), pred(y));
  }
}

bool is_neq(nat x, nat y) {
  if (is_undef(x) || is_undef(y) || is_infty(x) || is_infty(y)) {
    return false;
  }
  if (is_zero(x) && is_zero(y)) {
    return false;
  }
  if (is_zero(x) || is_zero(y)) {
    return true;
  } else {
    return is_neq(pred(x), pred(y));
  }
}

bool is_leq(nat x, nat y) {
  if (is_undef(x) || is_undef(y) || is_infty(x) || is_infty(y)) {
    return false;
  }
  if (is_zero(y) && is_zero(x)) {
    return true;
  }
  if (is_zero(y)) {
    return false;
  }
  if (is_zero(x)) {
    return true;
  } else {
    return is_leq(pred(x), pred(y));
  }
}

bool is_lth(nat x, nat y) {
  if (is_undef(x) || is_undef(y) || is_infty(x) || is_infty(y)) {
    return false;
  }
  if (is_zero(y)) {
    return false;
  }
  if (is_zero(x)) {
    return true;
  } else {
    return is_lth(pred(x), pred(y));
  }
}

bool is_geq(nat x, nat y) {
  if (is_undef(x) || is_undef(y) || is_infty(x) || is_infty(y)) {
    return false;
  }
  if (is_zero(y) && is_zero(x)) {
    return true;
  }
  if (is_zero(x)) {
    return false;
  }
  if (is_zero(y)) {
    return true;
  } else {
    return is_geq(pred(x), pred(y));
  }
}

bool is_gth(nat x, nat y) {
  if (is_undef(x) || is_undef(y) || is_infty(x) || is_infty(y)) {
    return false;
  }
  if (is_zero(x)) {
    return false;
  }
  if (is_zero(y)) {
    return true;
  } else {
    return is_gth(pred(x), pred(y));
  }
}
