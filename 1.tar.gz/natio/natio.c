#include "natio.h"
#include <ctype.h>
#include <errno.h>

#define CHRZERO '0'
#define CHRSUCC 's'
#define CHRPRED 'p'

#define STRINFTY  "INFTY"
#define STRUNDEF  "UNDEF"

//  input_leadingspaces : lecture sur le flot contrôlé par l'objet pointé par
//    stream d'une suite éventuellement vide de caractères d'espacement. La
//    lecture prend fin dès qu'une erreur survient ou qu'un caractère qui
//    n'appartient pas à la catégorie des caractères d'espacement est rencontré.
//    La fonction renvoie EOF dans le premier cas, la valeur renvoyée par la
//    réinjection du dernier caractère lu dans le second cas.
static int input_leadingspaces(FILE *stream);

//  input_body : même spécification que input mais en supposant que les
//    éventuels caractères d'espacement initiaux ont été lus.
static int input_body(FILE *stream, nat *ptr);

int input(FILE *stream, nat *ptr) {
  *ptr = undef();
  if (input_leadingspaces(stream) == EOF) {
    return EOF;
  }
  return input_body(stream, ptr);
}

int input_leadingspaces(FILE *stream) {
  int c = fgetc(stream);
  if (c == EOF) {
    return EOF;
  }
  if (!isspace(c)) {
    return ungetc(c, stream);
  }
  return input_leadingspaces(stream);
}

int input_body(FILE *stream, nat *ptr) {
  int c = fgetc(stream);
  if (c == EOF) {
    return 0;
  }
  if (c == CHRZERO) {
    *ptr = zero();
    return 1;
  }
  if (!(c == CHRSUCC || c == CHRPRED)
      || input_body(stream, ptr) == 0) {
    return 0;
  }
  *ptr = (c == CHRSUCC ? succ : pred)(*ptr);
  return 1;
}

//  output_body : même spécification que output mais en supposant que x ne
//    représente pas une valeur non définie.
static int output_body(FILE *stream, nat x);

int output(FILE *stream, nat x) {
  if (is_undef(x)) {
    return fputs(STRUNDEF, stream) == EOF ? EOF : 0;
  }
  if (is_infty(x)) {
    return fputs(STRINFTY, stream) == EOF ? EOF : 0;
  }
  return output_body(stream, x);
}

int output_body(FILE *stream, nat x) {
  if (is_zero(x)) {
    return fputc(CHRZERO, stream) == EOF ? EOF : 1;
  }
  if (fputc(CHRSUCC, stream) == EOF) {
    return EOF;
  }
  return output_body(stream, pred(x));
}

static nat dinput_body(int n);

int dinput(FILE *stream, nat *ptr) {
  int n;
  if (fscanf(stream, "%d", &n) != 1 || n < 0) {
    *ptr = undef();
    fgetc(stream);
    return 0;
  }
  *ptr = dinput_body(n);
  return 1;
}

nat dinput_body(int n) {
  if (n == 0) {
    return zero();
  }
  return succ(dinput_body(n - 1));
}

static int doutput_body(nat x);

int doutput(FILE *stream, nat x){
  if (is_undef(x) || is_infty(x)) {
    if (fprintf(stream, "%s", (is_undef(x)) ? STRUNDEF : STRINFTY) != 1) {
      return 0;
    }
  }
  if (fprintf(stream, "%d", doutput_body(x)) != 1) {
    return 0;
  }
  return 1;
}

int doutput_body(nat x) {
  if (is_zero(x)) {
    return 0;
  }
  return doutput_body(pred(x)) + 1;
}
