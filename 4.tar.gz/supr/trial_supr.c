#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include "supr.h"

#define STR(x)  #x
#define XSTR(x) STR(x)

#define NORMAL()  printf("\x1b[0m")
#define OTHER()   printf("\x1b[5m\x1b[3;37m")

int main(void) {
  srand((unsigned int) time(NULL));
  supr x;
  supr_rand(&x);
  printf("J'ai choisi une suite de %d lettres majuscules.\n"
      "Ces lettres, je les ai tirées au hasard parmi les %d premières"
      " lettres de\nl'alphabet usuel.\nMission pour toi si tu l'acceptes :"
      " deviner la suite des %d lettres.\n",
      SUPR_LENGTH, UPR_CARD, SUPR_LENGTH);
#if SUPR_COMPAR_LENGTH < SUPR_LENGTH
  OTHER();
  printf("(Psst ! Il ne fera la comparaison que sur %s !)\n",
      SUPR_COMPAR_LENGTH == 1
      ? "la première lettre"
      : "les " XSTR(SUPR_COMPAR_LENGTH) " premières lettres");
  NORMAL();
#endif
  while (1) {
    printf("\nTa proposition ? ");
    supr y;
    if (supr_fget(&y, stdin) != 1) {
      printf("\nTu arrêtes ? Dommage...\nJ'avais choisi ");
      supr_fput(&x, stdout);
      printf(".\nÀ une autre fois peut-être ?\n");
      OTHER();
      printf("(Petit joueur !!!)\n");
      NORMAL();
      printf("\n");
      return EXIT_FAILURE;
    }
    int c = supr_compar(&x, &y);
    if (c == 0) {
      printf("Tu as gagné !\nTu as découvert que j'avais choisi ");
      supr_fput(&x, stdout);
      printf(".\nBravo !\n");
      OTHER();
      printf("(Merci qui ??\?)\n");
      NORMAL();
      printf("\n");
      return EXIT_SUCCESS;
    }
    printf("Loupé !\n");
    OTHER();
    printf("(Psst ! Vise plus %s...)\n", c < 0 ? "bas" : "haut");
    NORMAL();
  }
}
