#include "supr.h"
#include <ctype.h>
#include <string.h>
#include <stdlib.h>

//  supr, détail d'implantation : la mémorisation dans le tableau se fait à
//    rebours.

int supr_fget(supr *ptr, FILE *stream) {
  int c;
  while ((c = fgetc(stream)) != EOF && isspace(c)) {
  }
  if (c == EOF || ungetc(c, stream) == EOF) {
    return EOF;
  }
  supr s;
  size_t k = SUPR_LENGTH;
  while (k != 0
      && (c = fgetc(stream)) != EOF
      && memchr(UPR_SET__FULL, c, UPR_CARD) != NULL) {
    --k;
    s.reserved__usage[k] = (char) c;
  }
  if (k != 0) {
    return 0;
  }
  *ptr = s;
  return 1;
}

int supr_fput(const supr *ptr, FILE *stream) {
  size_t k = SUPR_LENGTH;
  while (k != 0) {
    --k;
    if (fputc(ptr->reserved__usage[k], stream) == EOF) {
      return EOF;
    }
  }
  return 0;
}

void supr_rand(supr *ptr) {
  size_t k = SUPR_LENGTH;
  while (k != 0) {
    --k;
    ptr->reserved__usage[k]
      = *(UPR_SET__FULL + (size_t) ((double) UPR_CARD * rand() / RAND_MAX));
  }
}

int supr_compar(const supr *ptr1, const supr *ptr2) {
  size_t k = SUPR_LENGTH;
  while (k != SUPR_LENGTH - SUPR_COMPAR_LENGTH) {
    --k;
    int d = ptr1->reserved__usage[k] - ptr2->reserved__usage[k];
    if (d != 0) {
      return d;
    }
  }
  return 0;
}
