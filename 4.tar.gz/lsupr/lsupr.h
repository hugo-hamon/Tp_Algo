//  lsupr : List of Sequences of Upper case letters. Module permettant de gérer
//    des listes dynamiques simplement chainées sur le type supr défini dans le
//    module supr.

#ifndef LSUPR__H
#define LSUPR__H

#include "supr.h"
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

//  struct lsupr, lsupr : structure capable de gérer une liste dynamique
//    simplement chainée sur le type supr.
typedef struct lsupr lsupr;

//  lsupr_empty : crée un objet de type lsupr. La liste est initialement vide.
//    Renvoie un pointeur vers l'objet en cas de succès, NULL en cas d'échec.
extern lsupr *lsupr_empty(void);

//  lsupr_is_empty : renvoie true ou false selon que la liste associée à s est
//    vide ou non.
extern bool lsupr_is_empty(const lsupr *s);

//  lsupr_insert_head : insère une copie de *ptr en tête de la liste associée à
//    s. Renvoie zéro en cas de succès, une valeur non nulle en cas d'échec.
extern int lsupr_insert_head(lsupr *s, supr *ptr);

//  lsupr_head_value : si la liste associée à s n'est pas vide, affecte à *ptr
//    la valeur de l'élément de tête et renvoie zéro. Renvoie une valeur non
//    nulle sinon.
extern int lsupr_head_value(const lsupr *s, supr *ptr);

//  lsupr_move_head_head : déplace l'élément de tête de la liste associée à src
//    vers la tête de la liste associée à dest. Renvoie zéro en cas de succès,
//    une valeur non nulle en cas d'échec pour cause de liste associée à src
//    vide.
extern int lsupr_move_head_head(lsupr *src, lsupr *dest);

//  lsupr_fput : écrit sur le flot contrôlé par l'objet pointé par stream les
//    éléments de la liste associée à s. Les éléments sont écrits séparés par
//    une espace. Le délimiteur gauche est vide, le délimiteur droit est la fin
//    de ligne. Renvoie zéro en cas de succès, une valeur non nulle en cas
//    d'échec.
extern int lsupr_fput(const lsupr *s, FILE *stream);

//  lsupr_dispose : si *sptr ne vaut pas NULL, libère les ressources allouées à
//    *sptr ainsi qu'à la liste associée puis affecte la valeur NULL à *sptr.
extern void lsupr_dispose(lsupr **sptr);

#endif
