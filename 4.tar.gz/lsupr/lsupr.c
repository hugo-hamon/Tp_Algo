#include "lsupr.h"

typedef struct clsupr clsupr;

struct clsupr {
  supr value;
  clsupr *next;
};

struct lsupr {
  clsupr *head;
};

lsupr *lsupr_empty(void) {
  lsupr *s = malloc(sizeof *s);
  if (s == NULL) {
    return NULL;
  }
  s->head = NULL;
  return s;
}

bool lsupr_is_empty(const lsupr *s) {
  return s->head == NULL;
}

int lsupr_insert_head(lsupr *s, supr *ptr) {
  clsupr *p = malloc(sizeof *p);
  if (p == NULL) {
    return -1;
  }
  p->value = *ptr;
  p->next = s->head;
  s->head = p;
  return 0;
}

int lsupr_fput(const lsupr *s, FILE *stream) {
  clsupr *p = s->head;
  while (p != NULL) {
    if(supr_fput(&p->value, stream) == EOF || fputc(' ', stream) == EOF){
      return -1;
    }
    p = p->next;
  }
  if (fputc('\n', stream) == EOF){
    return -1;
  }
  return 0;
}

int lsupr_head_value(const lsupr *s, supr *ptr) {
  if (s->head == NULL) {
    return -1;
  }
  *ptr = s->head->value;
  return 0;
}

int lsupr_move_head_head(lsupr *src, lsupr *dest) {
  if (src->head == NULL) {
    return -1;
  }
  clsupr *t = dest->head;
  clsupr *p = src->head->next;
  dest->head = src->head;
  dest->head->next = t;
  src->head = p;
  return 0;
}

void lsupr_dispose(lsupr **sptr) {
  clsupr *p = (*sptr)->head;
  while (p != NULL) {
    clsupr *t = p;
    p = p->next;
    free(t);
  }
  free(*sptr);
  *sptr = NULL;
}
