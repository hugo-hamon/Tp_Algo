#include "lsupr_ext.h"

int lsupr_move_all_head(lsupr *src, lsupr *dest) {
  lsupr *p = lsupr_empty();
  if (p == NULL) {
    goto error;
  }
  while (!lsupr_is_empty(src) && lsupr_move_head_head(src, p) != -1) {
  }
  if (!lsupr_is_empty(src)) {
    goto error;
  }
  while (!lsupr_is_empty(p) && lsupr_move_head_head(p, dest) != -1) {
  }
  if (!lsupr_is_empty(src)) {
    goto error;
  }
  lsupr_dispose(&p);
  return 0;
error:
  lsupr_dispose(&p);
  return -1;
}

void lsupr_partition_pivot(lsupr *s, lsupr *slth, lsupr *seq, lsupr *sgth) {
  supr pivot;
  if (lsupr_head_value(s, &pivot) == -1) {
    return;
  }
  supr inc;
  while (!lsupr_is_empty(s) && lsupr_head_value(s, &inc) != -1) {
    if (supr_compar(&pivot, &inc) == 0) {
      lsupr_move_head_head(s, seq);
    } else if (supr_compar(&pivot, &inc) < 0) {
      lsupr_move_head_head(s, slth);
    } else {
      lsupr_move_head_head(s, sgth);
    }
  }
}

int lsupr_quicksort(lsupr *s) {
  if (lsupr_is_empty(s)){
    return -1;
  }
  lsupr *slth = lsupr_empty();
  lsupr *seq = lsupr_empty();
  lsupr *sgth = lsupr_empty();
  if (slth == NULL || seq == NULL || sgth == NULL) {
    return -1;
  }
  lsupr_partition_pivot(s, slth, seq, sgth);
  lsupr_quicksort(slth);
  lsupr_quicksort(sgth);
  lsupr_move_all_head(slth, s);
  lsupr_move_all_head(seq, s);
  lsupr_move_all_head(sgth, s);
  lsupr_dispose(&slth);
  lsupr_dispose(&seq);
  lsupr_dispose(&sgth);
  return 0;
}
