//  lsupr_ext : extension of the module lsupr. Extension du module lsupr.

#ifndef LSUPR_EXT__H
#define LSUPR_EXT__H

#include "lsupr.h"

//  lsupr_move_all_head : déplace en tête de la liste associée à dest la liste
//    associée à src, de telle sorte que, à la terminaison, la liste associée à
//    src est vide et la liste associée à dest est la concaténation des listes
//    originelles associées à src et dest. En cas de succès, la fonction renvoie
//    zéro. En cas d'échec, en particulier parce que src == dest, la fonction
//    renvoie une valeur non nulle.
int lsupr_move_all_head(lsupr *src, lsupr *dest);

//  lsupr_partition_pivot : déplace respectivement dans les listes associées à
//    slth, seq et sgth, les éléments de la liste associée à s qui sont
//    strictement inférieurs, égaux et strictement supérieurs au premier élément
//    de la liste associée à s. Si la liste associée à s est vide, les quatre
//    listes demeurent inchangées. À la terminaison, la liste associée à s est
//    vide.
void lsupr_partition_pivot(lsupr *s, lsupr *slth, lsupr *seq, lsupr *sgth);

//  lsupr_quicksort : recompose la liste associée à s selon la méthode du tri
//    rapide. Renvoie zéro en cas de succès, une valeur non nulle en cas
//    d'échec.
int lsupr_quicksort(lsupr *s);

#endif
