#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include "lsupr.h"
#include "lsupr_ext.h"

//  stop : lit des caractères sur l'entrée standard jusqu'à détecter la fin de
//    l'entrée ou obtenir 'q', 'Q' ou '\n'. Renvoie zéro si '\n' est obtenu, une
//    valeur non nulle sinon.
int stop(void);

#define NMEMB 16

int main(void) {
  printf("--- Trials on lsupr module\n"
      "--- Type ctrl-d or enter 'q' or 'Q' to exit\n\n");
  srand(0);
  lsupr *s;
  lsupr *s2;
  while (1) {
    s = lsupr_empty();
    s2 = lsupr_empty();
    if (s == NULL) {
      goto error;
    }
    for (int k = 0; k < NMEMB; ++k) {
      supr x;
      supr_rand(&x);
      lsupr_insert_head(s, &x);
    }
    printf("\n");
    lsupr_fput(s, stdout);
    for (int i = 0; i < NMEMB / 2; ++i){
      lsupr_move_head_head(s, s2);
      lsupr_fput(s, stdout);
      lsupr_fput(s2, stdout);
    }
    printf("\ns1\n");
    lsupr_fput(s, stdout);
    printf("s2 before\n");
    lsupr_fput(s2, stdout);
    lsupr_move_all_head(s, s2);
    printf("s2 after \n");
    lsupr_fput(s2, stdout);
    lsupr_quicksort(s2);
    printf("s2 after quicksort \n");
    lsupr_fput(s2, stdout);
    lsupr_dispose(&s);
    lsupr_dispose(&s2);
    printf("\n> ");
    if (stop()) {
      printf("\n");
      return EXIT_SUCCESS;
    }

  }
error:
  fprintf(stderr, "*** A fatal error occurs.\n");
  lsupr_dispose(&s);
  lsupr_dispose(&s2);
  return EXIT_FAILURE;
}

int stop(void) {
  while (1) {
    int c = getchar();
    if (c == EOF || toupper(c) == 'Q') {
      return 1;
    }
    if (c == '\n') {
      return 0;
    }
  }
}
