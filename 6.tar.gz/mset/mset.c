//  Implantation polymorphe pour la spécification MENS du TDA MEns(T) et son
//    extension MENSMIN. L'accès à l'extension MENSMIN requiert la définition de
//    la macroconstante MSETMIN.

#include "mset.h"

//  struct mset, mset : gestion des adresses des éléments dans le multi-ensemble
//    à l'aide d'une liste dynamique simplement chainée. Le composant compar
//    mémorise la fonction de comparaison des éléments à partir de leurs
//    adresses, le composant head a pour valeur le pointeur de tête de la liste,
//    le composant card mémorise le cardinal du multi-ensemble.

typedef struct cmset cmset;

struct cmset {
  const void *value;
  size_t mult;
  cmset *next;
};

struct mset {
  int (*compar)(const void *, const void *);
  cmset *head;
  size_t card;
};

mset *mset_empty(int (*compar)(const void *, const void *)) {
  mset *s = malloc(sizeof *s);
  if (s == NULL) {
    return NULL;
  }
  s->head = NULL;
  s->card = 0;
  s->compar = compar;
  return s;
}

bool mset_is_empty(mset *ms) {
  return ms->card == 0;
}

// search: recherche dans le muti-ensemble associé à ms un élément égal à celui
// d'adresse xptr au sens de compar. Si un tel élément existe, renvoie cette
// élément sinon renvoie NULL si aucun élément de la sorte exite.
static cmset **search(mset *ms, const void *xptr) {
  cmset **p = &(ms->head);
  while (*p != NULL && (ms->compar(xptr, (*p)->value) != 0)) {
    p = &(*p)->next;
  }
  return p;
}

const void *mset_add(mset *ms, const void *xptr) {
  if (xptr == NULL) {
    return NULL;
  }
  cmset **p = search(ms, xptr);
  if (*p != NULL) {
    (*p)->mult += 1;
    ms->card += 1;
    return (*p)->value;
  }
  *p = malloc(sizeof **p);
  if (*p == NULL) {
    return NULL;
  }
  (*p)->next = NULL;
  (*p)->value = xptr;
  (*p)->mult = 1;
  ms->card += 1;
  return xptr;
}

const void *mset_remove(mset *ms, const void *xptr) {
  if (xptr == NULL) {
    return NULL;
  }
  cmset **pp = search(ms, xptr);
  if (*pp != NULL) {
    ms->card -= 1;
    if ((*pp)->mult > 1) {
      (*pp)->mult -= 1;
      return (*pp)->value;
    }
    const void *rptr = (*pp)->value;
    cmset *t = *pp;
    *pp = (*pp)->next;
    free(t);
    return rptr;
  }
  return NULL;
}

const void *mset_remove_all(mset *ms, const void *xptr){
  if (xptr == NULL) {
    return NULL;
  }
  cmset **pp = search(ms, xptr);
  if (*pp != NULL){
    ms->card -= (*pp)->mult;
    const void *rptr = (*pp)->value;
    cmset *t = *pp;
    *pp = (*pp)->next;
    free(t);
    return rptr;
  }
  return NULL;
}

size_t mset_mult(mset *ms, const void *xptr) {
  if (xptr == NULL) {
    return 0;
  }
  cmset *p = ms->head;
  while (p != NULL) {
    if (ms->compar(xptr, p->value) == 0) {
      return p->mult;
    }
    p = p->next;
  }
  return 0;
}

size_t mset_card(mset *ms) {
  return ms->card;
}

#ifdef MSETMIN
const void *mset_min(mset *ms) {
  if (mset_is_empty(ms)) {
    return NULL;
  }
  cmset *p = ms->head;
  cmset *min = p;
  while (p != NULL) {
    if (ms->compar(p->value, min->value) < 0) {
      min = p;
    }
    p = p->next;
  }
  return min->value;
}

#endif

void mset_dispose(mset **msptr) {
  if (*msptr == NULL) {
    return;
  }
  cmset *p = (*msptr)->head;
  while (p != NULL) {
    cmset *t = p;
    p = p->next;
    free(t);
    (*msptr)->card -= 1;
  }
  free(*msptr);
  *msptr = NULL;
}

// retrait-tous
